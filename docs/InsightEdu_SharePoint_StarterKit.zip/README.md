# InsightEdu SharePoint Starter Kit (Education)

**Last updated:** 2025-09-05

This starter kit provisions a baseline SharePoint hub and a client-facing site with education-tailored content types, document sets, and lists. It’s designed to be deployed in a clean M365 tenant for demos or as a repeatable accelerator in client tenants.

## What this includes
- **PnP template** defining reusable **site columns**, **content types** (Policy, Risk Assessment, Trip Pack, Inspection Evidence), and a **Document Set** for policies/trips.
- **PnP.PowerShell** script to create a hub site and a client site, associate them, and apply the template.
- **Sample Power Automate flow skeletons** for policy lifecycle approval and trip approval (import to Power Automate and finish connectors).
- **List view formatting** samples for WAAG, Inspection Evidence RAG badges, and Trip Requests stage chips.

## Prereqs
- PowerShell 7+
- `PnP.PowerShell` module (`Install-Module PnP.PowerShell -Scope CurrentUser`)
- SharePoint Online admin permissions in the target tenant.

## Quick start
```powershell
# Authenticate and provision
cd ./scripts
./provision.ps1 `
  -TenantAdminUrl "https://YOURTENANT-admin.sharepoint.com" `
  -HubTitle "InsightEdu Hub" `
  -ClientSiteUrl "https://YOURTENANT.sharepoint.com/sites/InsightEduClient" `
  -ClientSiteTitle "InsightEdu Client Workspace"
```

After the script runs:
1. Open the client site → **Site contents** and verify the lists: *Inspection Evidence*, *WAAG*, *Trip Requests*.
2. Import the two sample flows in Power Automate and connect to the new lists.
3. Add the **Copilot Studio** bot (not included here) to the client site page and grant it access to the libraries/lists you want it to query.

## Notes
- Document Sets require classic feature activation, enabled by the PnP template step.
- For analytics at scale, pair this with Fabric or SQL; use Dataverse for complex relational apps.
- This kit is a foundation—extend safely using managed solutions and PnP templates.
